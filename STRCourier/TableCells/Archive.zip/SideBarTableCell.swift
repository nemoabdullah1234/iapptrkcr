//
//  SideBarTableCell.swift
//  Stryker
//
//  Created by Nitin Singh on 13/06/16.
//  Copyright © 2016 OSSCube. All rights reserved.
//

import UIKit

class SideBarTableCell: UITableViewCell {
    @IBOutlet var imgName: UIImageView!
    @IBOutlet var lblName: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        setUpFont()
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    func setUpFont(){
        
        // lblName!.font = FontXtraSmall.Body
    }
    
    
}
